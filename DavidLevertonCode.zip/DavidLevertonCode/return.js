//this function prevents the data being sent to the database before it has been validated
$ ("#formValidate").submit( function() {
	return false;
});
