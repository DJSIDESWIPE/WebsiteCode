
<?php
	class Training {
		function TrainingDetails() {
			$this->MandatoryTraining();
			$this->NonMandatoryTraining();
		}
		private function MandatoryTraining() {
			echo "<h2>Mandatory Trainng</h2>";
			$conn = $this->Connection();
			$sql = "SELECT * FROM Training WHERE Type='Mandatory'";//gets all data for non-manditory training
			$result = mysqli_query($conn, $sql);
			$this->DisplayTrainingDetails($result);
		}
		private function NonMandatoryTraining() {
			echo "<h2>Non-Mandatory Training</h2>";
			$conn = $this->Connection();
			$sql = "SELECT * FROM Training WHERE Type='Non-Mandatory'";//gets all data for non-manditory training
			$result = mysqli_query($conn, $sql);
			$this->DisplayTrainingDetails($result);
		}
		private function Connection() {
			include("Connections.php");//connection to the database
			return $conn;
		}
		
		private function DisplayTrainingDetails($result) {
			$count = 1;
			while($row = mysqli_fetch_array($result)) {
				echo "<p>" . $count . " Training name: " . $row['TrainingName']. "</p>" ;
				$count++;
			}
		}
		
		
	}
?>
