<html>
	<head>
		<link href="NavBar.css" Rel="stylesheet" type="text/css">
		<link href="MainStyle.css" Rel="stylesheet" type="text/css">
		<script src="NavBar.js"></script>
		<script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
		<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script><!--these validate the form using jquery-->
		<link href="bootstrap.css" rel="stylesheet" type="text/css">
		
		<script src="return.js"></script>
		<script src="validation.js"></script>
		<style type="text/css">
			body {
				font-size:400%;
				text-height:100%;
			}
			h1 {
				font-size:200%;
			}
</style>
	</head>
	<body>

		<div class="menu">
			<button onclick="menuFunction()" class="menuBtn">Menu</button>
			<div id="dropdownMenu" class="menuContent">
				<a href="HRPage.php">HR Page</a><!--the options of the navbar-->
				<a href="TrainingPage.php">Training Page</a><!--the options of the navbar-->
				<a href="LoginPage.php">Login Page</a>
			</div>
		</div>
		
		<div class="PageContent">
			
			<!--this form allows the HR department to register new employees-->
			<form id="formValidate" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<h1>Registration<br /> Page</h1>
				<input type="text" name="Firstname" id="Firstname" placeholder="Firstname"><br />
				<input type="text" name="Lastname" id="Lastname" placeholder="Lastname"><br />
				<input type="text" name="Username" id="Username" placeholder="Username"><br />
				<input type="password" name="Password" id="Password" placeholder="Password" autocomplete="Off"><br />
				<input type="password" name="CheckPassword" id="CheckPassword" placeholder="Retype password" autocomplete="Off"><br />
				<input type="text" name="JobTitle" id="JobTitle" placeholder="Job title"><br />
				<input type="text" name="JobDescription" id="JobDescription" placeholder="Job description"><br />
				<input type="submit"  name="submit" id="submit" value="Add User">
			</form>
			<div class="errorTxt"><!--error messages of the form is put here and apear on the right side of the screen because of bootstrap-->
			</div>
			<?php
				include("RegistrationClass.php");//sends data to the database by using registrationdb.php
				$Register = new Registration();
				$Register->StaffRegistration();
			?>
		</div>
		
	</body>
</html>