<html>
	<head>
		<link href="NavBar.css" Rel="stylesheet" type="text/css">
		<link href="MainStyle.css" Rel="stylesheet" type="text/css">
		<link href="bootstrap.css" rel="stylesheet" type="text/css">
		<script src="NavBar.js"></script>
		<style type="text/css">
			body {
				font-size:200%;
				text-height:100%;
			}
			h1 {
				font-size:200%;
			}
			p {
				font-size:150%;
			}
			form {
				font-size:150%;
			}
</style>
	</head>
	<body>

		<div class="menu">
			<button onclick="menuFunction()" class="menuBtn">Menu</button>
			<div id="dropdownMenu" class="menuContent">
				<a href="RegistrationPage.php">Registration Page</a><!--the options of the navbar-->
				<a href="TrainingPage.php">Training Page</a><!--the options of the navbar-->
				<a href="LoginPage.php">Login Page</a>
			</div>
		</div>
		
		<div class="PageContent">
			<h1>Welcome to the HR Page</h1>
			<p>On this page you can search for employee details and create a new training course</p>
			<p>To register staff use the navbar and select registration page</p>
			<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<h2>Search for employee</h2>
				<input type="text" name="Firstname" id="Firstname" placeholder="Firstname of Staff"><br />
				<input type="text" name="Lastname" id="Lastname" placeholder="Lastname of staff"><br />
				<input type="submit" value="Search for staff">
			</form>
			<?php
				include("HRClass.php");
				$HR = new HR();
				$HR->DisplayStaffDetails();
			?>
			
			<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<h2>Create training</h2>
				<input type="text" name="Name" id="Name" placeholder="Name of Training"><br />
				Mandatory:<input type="radio" name="Type" id="Type" value="Mandatory">
				Non-Mandatory:<input type="radio" name="Type" id="Type" value="Non-Mandatory"><br />
				<input type="text" name="Description" id="Description"placeholder="Description of Training"><br />
				<input type="submit" value="Add training"><br />
				<?php
				$HR->AddTraining();
			?>
			</form>
			
		</div>
		
	</body>
</html>