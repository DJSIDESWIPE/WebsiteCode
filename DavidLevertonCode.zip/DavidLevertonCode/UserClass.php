<?php
	class User {//parent class that other classes inherit
		protected $Fullname;
		protected $Username;
		protected $Password;
		protected $JobTitle;
		protected $JobDescription;
	
	} 
?>