<html>
	<head>
		<link href="NavBar.css" Rel="stylesheet" type="text/css">
		<link href="MainStyle.css" Rel="stylesheet" type="text/css">
		<link href="bootstrap.css" rel="stylesheet" type="text/css">
		<script src="NavBar.js"></script>
		<style type="text/css">
			body {
				font-size:200%;
				text-height:100%;
			}
			p {
				font-size:100%;
			}
			form {
				text-align:center;
				font-size:150%;
			}
</style>
		<?php
			include("Connections.php");
		?>
	</head>
	<body>

		<div class="menu">
			<button onclick="menuFunction()" class="menuBtn">Menu</button>
			<div id="dropdownMenu" class="menuContent">
				<a href="TrainingPage.php">Training Page</a><!--the options of the navbar-->
				<a href="LoginPage.php">Login Page</a>
			</div>
		</div>
		
		<div class="PageContent">
			
			<h1>Welcome to the Staff Page</h1>
			<p>Below you can see your details and apply for a training course</p>
			<?php //calls the class and function
				include("StaffClass.php");
				$Staff = new Staff();
				$Staff->EmployeeDetails();
			?>
			<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<h1>Attend Training</h1>
				<?php
					$User = "root";
					$Password = "password";
					$LocalHost = "localhost";//creates the connection to the database
					$Database = "Training";

					$conn = mysqli_connect($LocalHost,$User,$Password,$Database);
					$sql = "SELECT * FROM Training";
					$result = mysqli_query($conn, $sql);
					while($row = mysqli_fetch_array($result)) {
						$Training = $row['TrainingName'];
						echo $Training . "<input class=form type=radio name='Training' value='$Training'><br />";
						
					}
				?>
				<input type="submit" value="Attend training">
			</form>
			<?php
				$Staff->AttendTraining();
			?>
		</div>
		
	</body>
</html>