<?php
	include("CleanInput.php");
	class Registration {
		
		private $firstname;
		private $lastname;
		private $username;
		private $password;
		private $JobTitle;
		private $JobDescription;
		
		function StaffRegistration() {
			$this->UserInput();
			$conn = $this->connection();
			//inputs data to the database
			
			if ($this->firstname == "" or $this->lastname == "" or  $this->username == "" or  $this->password == "" or  $this->JobTitle == "" or  $this->JobDescription == "") {
				
			} else {
				$sql = "INSERT INTO Staff (Firstname, Lastname, Username, Password, JobTitle, JobDescription)
				VALUES ('$this->firstname', '$this->lastname', '$this->username', '$this->password','$this->JobTitle','$this->JobDescription')";//inputs the values into the table
		
				$this->checkregistration($conn, $sql);
			}
			
					
			
			
		}
		
		private function UserInput() {
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$this->firstname = clean_input($_POST["Firstname"]);
				$this->lastname = clean_input($_POST["Lastname"]);
				//checks that all the data being put in the database doesn't have any code in
				$this->username = clean_input($_POST["Username"]);
				$this->password = clean_input($_POST["Password"]);
				$this->checkpassword = clean_input($_POST["CheckPassword"]);
				$this->JobTitle = clean_input($_POST["JobTitle"]);//inputs from the form
				$this->JobDescription = clean_input($_POST["JobDescription"]);
			}
		}
		
		private function checkregistration($conn, $sql) {
			if ($conn->query($sql) === TRUE) {//checks if the sql has been successful or not
  				echo "New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
			}
		}
		
		private function connection() {
			include("Connections.php");
			return $conn;
		}
	}
?>