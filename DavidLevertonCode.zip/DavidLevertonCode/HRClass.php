<?php
	include("UserClass.php");
?>
<?php
	include("CleanInput.php");
	class HR extends User {
		
		private $Name;
		private $Type;
		private $Description;
		
		function DisplayStaffDetails() {//checks the first and last name that is entered then gets the data for that name
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$Firstname = clean_input($_POST["Firstname"]);
				$Lastname = clean_input($_POST["Lastname"]);
				$conn = $this->connection();
				$sql = "SELECT * FROM Staff WHERE Firstname = '$Firstname' AND Lastname='$Lastname'";
				$result = mysqli_query($conn, $sql);
				while($row = mysqli_fetch_array($result)) {
					$this->Fullname = $row['Firstname'] . " " . $row['Lastname'];
					$this->Username = $row['Username'];
					$this->JobTitle = $row['JobTitle'];
					$this->JobDescription = $row['JobDescription'];//stores the employees data
					
					echo "Employee name: " . $this->Fullname . "<br />Their username: " . $this->Username . "<br /> Their job title: " . $this->JobTitle . "<br /> Their job description: " . $this->JobDescription;
				}
				
			}
		}
		
		function AddTraining() {
			$this->GetTrainingInput();
			
			$conn = $this->connection();

			if ($this->Name == "" or $this->Type == "" or $this->Description == "") {//won't add empty data to the database
				echo "Field is empty";
			} else {
				echo "Name of training: " . $this->Name . "<br />Type of training: "
					. $this->Type . "<br />Description of training: " . $this->Description;
				
				$sql = "INSERT INTO Training (TrainingName, Type, Description)
				VALUES ('$this->Name', '$this->Type','$this->Description')";//inputs the values into the table
		
				$this->CheckSuccess($conn, $sql);
			}
		}
		
		private function GetTrainingInput() {
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$this->Name = clean_input($_POST["Name"]);
				$this->Type = clean_input($_POST["Type"]);//gets the users input from the form
				$this->Description = clean_input($_POST["Description"]);
			}
		}
		
		private function CheckSuccess($conn, $sql) {
			if ($conn->query($sql) === TRUE) {//checks if the sql has been successful or not
  				echo "New Training added";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
			}
		}
		
		private function connection() {
			include("Connections.php");
			return $conn;//conection to the database
		}
		
	}
?>