<?php
	$User = "root";
	$Password = "password";
	$LocalHost = "localhost";//creates the connection to the database
	$Database = "Training";

	$conn = mysqli_connect($LocalHost,$User,$Password,$Database);
?>