<html>
<head>
	<link rel="stylesheet" type="text/css" href="Splash.css"><!--changes the colour of background and size of the image-->
	<meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
	<title>Aviva Training App</title>
	
	<script>
	// creating and calling a function that loads the page and after 6 seconds redirect user to the main page.
	window.setTimeout(function(){
		 window.location.href = "LoginPage.php";
    }, 5000);
	</script>
</head>
<body>
	<!-- creating container that stores logo and title -->
	<div>
		<img src="Aviva.png">
		<h1>Aviva training App</h1>
	</div>
</body>
</html>