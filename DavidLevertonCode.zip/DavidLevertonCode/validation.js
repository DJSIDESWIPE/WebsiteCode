function validate() {
	$.validator.setDefaults({
		submitHandler: function() {
			alert("submitted!");
		}
	});
}
//uses JQuery to set rules for the html tags with these names
$().ready(function() {

	$("#formValidate").validate({
		rules: {
			Firstname: "required",
			Lastname: "required",
			JobTitle: "required",
			JobDescription: "required",
			Username: {
				required: true,
					minlength: 2
			},
			Password: {
				required: true,
				minlength: 5
			},
			CheckPassword: {
				required: true,
				minlength: 5,
				equalTo: "#Password"
			},

		},
		messages: {
			//messages for each of the errors that can occur
			Firstname: "<div class='alert alert-danger'>Please enter the employees firstname</div>",
			Lastname: "<div class='alert alert-danger'>Please enter the employees lastname</div>",
			JobTitle: "<div class='alert alert-danger'>Please enter the employees job title</div>",
			JobDescription: "<div class='alert alert-danger'>Please enter the employees job description</div>",
			Username: {
				required: "<div class='alert alert-danger'>Please enter a username</div>",
				minlength: "<div class='alert alert-danger'>The username must consist of at least 2 characters</div>"
			},
			Password: {
				required: "<div class='alert alert-danger'>Please provide a password</div>",
				minlength: "<div class='alert alert-danger'>The password must be at least 5 characters long</div>"
			},
			CheckPassword: {
				required: "<div class='alert alert-danger'>Please provide a password</div>",
				minlength: "<div class='alert alert-danger'>The password must be at least 5 characters long</div>",
				equalTo: "<div class='alert alert-danger'>Please enter the same password as above</div>"
			},
			
		},
		errorElement : 'div',
		errorLabelContainer: '.errorTxt'//puts the error messages in a specific place
		
	});
});