<html>
	<head>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script><!--These libraries allow for bootstrap to work-->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script src="NavBar.js"></script>
		<link href="MainStyle.css" Rel="stylesheet" type="text/css">
		<link href="bootstrap.css" rel="stylesheet" type="text/css">
		<style type="text/css">
			body {
				font-size:400%;
				text-height:100%;
				
			}
			h1 {
				font-size:200%;
			}
</style>
		<link href="NavBar.css" Rel="stylesheet" type="text/css">
	</head>
	<body>
		<div class="menu">
			<button onclick="menuFunction()" class="menuBtn">Menu</button>
			<div id="dropdownMenu" class="menuContent">
				<a href="TrainingPage.php">Training Page</a><!--the options of the navbar-->
				<a href="LoginPage.php">Login Page</a>
			</div>
		</div>
		<div class="PageContent">
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-12">
						<h1>Welcome</h1>
						<p>To the Aviva Training App please login to your account</p>
						<h1>Login</h1>
						<form method="POST">
							<input type="text" name="username" id="username" placeholder="Username" autocomplete="off"> <br /> 
							<!--auto complete off protects from client side threats-->
							<input type="password" name="password" id="password" autocomplete="off" placeholder="Password"> <br />
							<input type="submit" name="login" value="Login" onClick="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
						</form>
					</div>
				</div>
			

			<div class="col-sm-12">
				<?php
					include("LoginClass.php");//outputs messages here
					$login = new Login();//calls the login class
					$login->UserLogin();
				?>
			</div>
		</div>
	</div>
		
	</body>
</html>