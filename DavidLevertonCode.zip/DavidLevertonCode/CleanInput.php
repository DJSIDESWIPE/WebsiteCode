<?php
	function clean_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);//cleans the imput so that no code is entered into the database that could cause damage
		return $data;
	}
?>