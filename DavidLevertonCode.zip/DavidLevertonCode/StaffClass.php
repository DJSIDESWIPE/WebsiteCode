<?php
	include("UserClass.php");
?>
<?php
	include("CleanInput.php");
	class Staff extends User {
		
		private $Training;
		private $FullName;
		
		function EmployeeDetails() {
			$this->FullName = $_COOKIE['UserName'];
			$conn = $this->connection();
			$sql = "SELECT * FROM Staff";
			$result = mysqli_query($conn, $sql);
			while($row = mysqli_fetch_array($result)) {
				$Fullname = $row['Firstname']. " " . $row['Lastname'];
				if ($this->FullName == $Fullname) {
					$this->Fullname = $row['Firstname'] . " " . $row['Lastname'];
					$this->Username = $row['Username'];
					$this->JobTitle = $row['JobTitle'];
					$this->JobDescription = $row['JobDescription'];//stores the employees data
					
					echo "Employee name: " . $this->FullName . "<br />Username: " . $this->Username . 
						"<br /> Job title: " . $this->JobTitle . "<br /> Job description: " . $this->JobDescription;
					$this->TrainingSelected();
				}
			}
		}
		private function GETINPUT() {
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$this->Training = clean_input($_POST["Training"]);
				$this->FullName = $_COOKIE['UserName'];
				//declares variables and gets users inputs
			}
		}
		
		function AttendTraining() {
			$this->GETINPUT();
			if ($this->Training == "") {
				echo "Training field is empty";
			} else {
				echo $this->Training;
				echo $this->FullName;
				$conn = $this->connection();
				$sql = "INSERT INTO Training_Request (TrainingName, StaffName)
				VALUES ('$this->Training', '$this->FullName')";//inputs the values into the table
		
				$this->checkregistration($conn, $sql);
			}
			
		}
		
		private function connection() {
			include("Connections.php");
			return $conn;//conection to the database
		}
		private function checkregistration($conn, $sql) {
			if ($conn->query($sql) === TRUE) {//checks if the sql has been successful or not
  				echo "New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
			}
		}
		private function TrainingSelected() {
			$conn = $this->connection();
			$sql = "SELECT * FROM Training_Request WHERE StaffName = '$this->FullName'";
			$result = mysqli_query($conn, $sql);
			echo "<br />";
			while($row = mysqli_fetch_array($result)) {
				echo "Training signed up for: " . $row['TrainingName'] . "<br />";
			}
		}
	}
?>