<html>
	<head>
		<meta name="viewpoint" content="width=device-width, initial-scale=1">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script><!--These libraries allow for bootstrap to work-->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script src="NavBar.js"></script>
		<link href="MainStyle.css" Rel="stylesheet" type="text/css">
		<link href="bootstrap.css" rel="stylesheet" type="text/css">
		<link href="NavBar.css" Rel="stylesheet" type="text/css">
<style type="text/css">
			body {
				font-size:200%;
				text-height:100%;
			}
			h1 {
				font-size:200%;
			}
</style>
	</head>
	<body>

		<div class="menu">
			<button onclick="menuFunction()" class="menuBtn">Menu</button>
			<div id="dropdownMenu" class="menuContent">
				<a href="TrainingPage.php">Training Page</a><!--the options of the navbar-->
				<a href="LoginPage.php">Login Page</a>
			</div>
		</div>
		<div class="col-sm-12">
			<h1>Training Courses</h1>
			<p>Mandatory and non-mandatory training courses available</p>
			<?php
				include("TrainingClass.php");
				$Details = new Training();//uses the training class to display the data from the database
				$Details->TrainingDetails();
				
			?>
		</div>
		
	</body>
</html>