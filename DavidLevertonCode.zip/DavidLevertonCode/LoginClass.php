<?php
	include("CleanInput.php");
?>
<?php
	class Login
	{
		private $Loginname;
		private $Loginpassword;
		private $UserIs;
		private $UserName;
		
		//gets the inputs from the user
		private function GETINPUT() {
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				
				$this->Loginname = clean_input($_POST["username"]);//declares variables and gets users inputs
				$this->Loginpassword = clean_input($_POST["password"]);	
				
			}
		}
		
		function UserLogin() {

			$this->GETINPUT();//gets the users inputs
			
			$conn = $this->connection();
			$sql = "SELECT * FROM Staff";
			$result = mysqli_query($conn, $sql);
			while($row = mysqli_fetch_array($result)) {
				if ($row['Username'] == $this->Loginname and $row['Password'] == $this->Loginpassword) {
					$this->UserIs = $row['JobTitle'];
					$this->UserName = $row['Firstname'] . " " . $row['Lastname'];
				}
			}
			if ($this->UserIs == "HR") {
				echo "<script>window.location.href = 'HRPage.php'</script>";
			} else if ($this->UserIs != "") {
				
				echo $this->UserName;
				setcookie("UserName", $this->UserName);
				echo "<script>window.location.href = 'StaffPage.php'</script>";
			} else {
				echo "incorrect username or password";
			}
			
			//checks what type of user it is and then calls the class that the user needs
					
		}
		private function connection() {
			include("Connections.php");
			return $conn;//conection to the database
		}
		
	}
?>